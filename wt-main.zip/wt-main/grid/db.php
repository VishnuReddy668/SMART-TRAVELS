<?php
$con=mysqli_connect("localhost","root","","priya");
if(!$con)
{
    die("Connection Error");
}
?>